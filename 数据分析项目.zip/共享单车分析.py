import pandas as pd
import matplotlib.pyplot as plt
import geopandas as gpd
from shapely.geometry import Point,Polygon,shape,LineString
import math
plt.rcParams['font.sans-serif'] = ['SimHei'] # 设置中文字体为黑体
plt.rcParams['axes.unicode_minus'] = False # 解决负号显示异常

# 计算栅格
shp = r'D:\code\JupyterProject\data\sz.shp'
sz = gpd.GeoDataFrame.from_file(shp,encoding = 'utf-8')

LONCOL = []
LATCOL = []
geometry = []
HBLON1 = []
HBLAT1 = []
#栅格化
lon1 = 113.716
lon2 = 114.633
lat1 = 22.400
lat2 = 22.866

latStart = min(lat1,lat2)
lonStart = min(lon1,lon2)
accuracy = 500
deltaLon = accuracy * 360 / (2 * math.pi * 6371004 * math.cos((lat1 + lat2) * math.pi / 360))
deltaLat = accuracy * 360 / (2 * math.pi * 6371004)

# 计算栅格总数
lonsnum = int((lon2-lon1)/deltaLon)+1
latsnum = int((lat2-lat1)/deltaLat)+1

for i in range(lonsnum):
    for j in range(latsnum):
        HBLON = i*deltaLon + (lonStart-deltaLon/2)
        HBLAT = j*deltaLat + (latStart-deltaLat/2)
        LONCOL.append(i)
        LATCOL.append(j)
        HBLON1.append(HBLON)
        HBLAT1.append(HBLAT)

        #用周围栅格算出顶点位置
        HBLON_1 = (i+1)*deltaLon + (lonStart-deltaLon/2)
        HBLAT_1 = (j+1)*deltaLat + (latStart-deltaLat/2)
        geometry.append(Polygon([
        (HBLON-deltaLon/2,HBLAT-deltaLat/2),
        (HBLON_1-deltaLon/2,HBLAT-deltaLat/2),
        (HBLON_1-deltaLon/2,HBLAT_1-deltaLat/2),
        (HBLON-deltaLon/2,HBLAT_1-deltaLat/2)]))

data = gpd.GeoDataFrame({
    'LONCOL': LONCOL,
    'LATCOL': LATCOL,
    'HBLON': HBLON1,
    'HBLAT': HBLAT1,
    'geometry': geometry
})
grid = data[data.intersects(sz.union_all())]

# 提取数据
Bike = pd.read_csv(r'D:\code\JupyterProject\data\共享单车企业每日订单表.csv',encoding = 'utf-8')

BikeOD = pd.DataFrame({'Stime':Bike['开始时间'],'SLng':Bike['开始经度'],'SLat':Bike['开始纬度'],'Etime':Bike['结束时间'],'ELng':Bike['结束经度'],'ELat':Bike['结束纬度']})

BikeOD['SLONCOL'] = ((BikeOD['SLng'] - (lonStart - deltaLon/2))/deltaLon).astype(int)
BikeOD['SLATCOL'] = ((BikeOD['SLat'] - (latStart - deltaLat / 2))/deltaLat).astype(int)
BikeOD['SHBLON'] = BikeOD['SLONCOL']*deltaLon + (lonStart - deltaLon / 2)
BikeOD['SHBLAT'] = BikeOD['SLATCOL']*deltaLat + (latStart - deltaLat / 2)
BikeOD['ELONCOL'] = ((BikeOD['ELng'] - (lonStart - deltaLon / 2))/deltaLon).astype('int')
BikeOD['ELATCOL'] = ((BikeOD['ELat'] - (latStart - deltaLat / 2))/deltaLat).astype('int')
BikeOD['EHBLON'] = BikeOD['ELONCOL']*deltaLon + (lonStart - deltaLon / 2)
BikeOD['EHBLAT'] = BikeOD['ELATCOL']*deltaLat + (latStart - deltaLat / 2)

#筛选去掉不在研究范围内的栅格
BikeOD = BikeOD[-((BikeOD['SLONCOL']==BikeOD['ELONCOL'])&(BikeOD['SLATCOL']==BikeOD['ELATCOL']))]
BikeOD = BikeOD[(BikeOD['SLONCOL']>=0) & (BikeOD['SLATCOL']>=0) &(BikeOD['ELONCOL']>=0) & (BikeOD['ELATCOL']>=0)&
(BikeOD['SLONCOL']<=lonsnum) & (BikeOD['SLATCOL']<=latsnum) &(BikeOD['ELONCOL']<=lonsnum) & (BikeOD['ELATCOL']<=latsnum)]

#计算起点
BikeOD['SHBLON'] = BikeOD['SLONCOL'] * deltaLon + (lonStart - deltaLon / 2)
BikeOD['SHBLAT'] = BikeOD['SLATCOL'] * deltaLat + (latStart - deltaLat / 2)
#计算终点
BikeOD['EHBLON'] = BikeOD['ELONCOL'] * deltaLon + (lonStart - deltaLon / 2)
BikeOD['EHBLAT'] = BikeOD['ELATCOL'] * deltaLat + (latStart - deltaLat / 2)

BikeOD['geometry'] = BikeOD.apply(lambda r:LineString([[r['SHBLON'],r['SHBLAT']],[r['EHBLON'],r['EHBLAT']]]),axis = 1)
BikeOD = gpd.GeoDataFrame(BikeOD)

# 画图
fig     = plt.figure(1,(10,8),dpi = 250)
ax      = plt.subplot(111)
ax.set_xlim(113.6,114.8)
ax.set_ylim(22.4,22.9)
plt.sca(ax)
plt.title("深圳某时段共享单车订单OD图(抽样)")
plt.xlabel("经度")
plt.ylabel("纬度")
sz.plot(ax=ax,linewidths=0.5,edgecolor="gray",facecolor = "none",zorder=0)
grid.plot(ax =ax,edgecolor = "white",facecolor = "none",linewidths=0.1,zorder=1)
BikeOD.plot(ax = ax,linewidths=0.2,zorder=2)

plt.savefig(r"深圳栅格网格图.png")















